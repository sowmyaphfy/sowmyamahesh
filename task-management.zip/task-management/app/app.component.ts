// src/app/app.component.ts
import { Component, OnInit } from '@angular/core';
import { Task } from './models/task.model';
import { TaskService } from './services/task.service';
import { MatDialog } from '@angular/material/dialog';
import { AddTaskDialogComponent } from './components/components/add-task-dialog/add-task-dialog.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  todoTasks: Task[] = [];
  inProgressTasks: Task[] = [];
  doneTasks: Task[] = [];

  constructor(private taskService: TaskService, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks(): void {
    this.taskService.getTasks().subscribe(tasks => {
      this.todoTasks = tasks.filter(task => task.status === 'To Do');
      this.inProgressTasks = tasks.filter(task => task.status === 'In Progress');
      this.doneTasks = tasks.filter(task => task.status === 'Done');
    });
  }

  openAddTaskDialog(): void {
    const dialogRef = this.dialog.open(AddTaskDialogComponent, {
      width: '500px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.taskService.addTask(result).subscribe(() => {
          this.loadTasks();
        });
      }
    });
  }

  onTaskDropped(event: any): void {
    // This would be called when a task is dropped in a new column
    const task = event.item.data;
    task.status = event.container.id;
    this.taskService.updateTask(task).subscribe(() => {
      this.loadTasks();
    });
  }
}