import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class BooksService {
  private apiUrl = 'https://www.googleapis.com/books/v1/volumes?q=fouling';

  constructor(private http: HttpClient) {}

  getBooks(): Observable<any> {
    return this.http.get(this.apiUrl).pipe(
      catchError(error => throwError(() => new Error('Failed to fetch books')))
    );
  }
}
