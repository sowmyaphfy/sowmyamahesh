import { Injectable } from '@angular/core';
import { Product, CartItem } from '../models/product.model';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private products: Product[] = [
    {
      id: 1,
      name: 'Men Slim Fit Solid Casual Shirt',
      brand: 'H&M',
      price: 899,
      originalPrice: 1299,
      discount: 30,
      size: ['S', 'M', 'L', 'XL'],
      colors: ['Red', 'Blue', 'White', 'Black'],
      images: [
        'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/1700861/2019/5/27/1d8c2a3e-8c1e-4f6f-9b8b-3b3e3b3b3b3b1558945675216-H-M-Men-Shirts-4691558945674328-1.jpg',
        'https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/1700861/2019/5/27/1d8c2a3e-8c1e-4f6f-9b8b-3b3e3b3b3b3b1558945675216-H-M-Men-Shirts-4691558945674328-2.jpg'
      ],
      description: 'Slim fit solid casual shirt, has a spread collar, long sleeves, curved hem',
      category: 'Men',
      rating: 4.2,
      reviews: 1245,
      inStock: true,
      isTrending: true
    },
    // Add more products...
  ];

  private cartItems: CartItem[] = [];
  private cartSubject = new BehaviorSubject<CartItem[]>(this.cartItems);

  constructor() {}

  getProducts(): Product[] {
    return this.products;
  }

  getProductById(id: number): Product | undefined {
    return this.products.find(product => product.id === id);
  }

  getCart(): Observable<CartItem[]> {
    return this.cartSubject.asObservable();
  }

  addToCart(product: Product, quantity: number = 1, size?: string, color?: string): void {
    const existingItem = this.cartItems.find(item => 
      item.product.id === product.id && 
      item.selectedSize === size && 
      item.selectedColor === color
    );

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      this.cartItems.push({
        product,
        quantity,
        selectedSize: size,
        selectedColor: color
      });
    }

    this.cartSubject.next(this.cartItems);
  }

  removeFromCart(item: CartItem): void {
    const index = this.cartItems.indexOf(item);
    if (index > -1) {
      this.cartItems.splice(index, 1);
      this.cartSubject.next(this.cartItems);
    }
  }

  updateCartItem(item: CartItem, quantity: number): void {
    const index = this.cartItems.indexOf(item);
    if (index > -1) {
      this.cartItems[index].quantity = quantity;
      this.cartSubject.next(this.cartItems);
    }
  }

  clearCart(): void {
    this.cartItems = [];
    this.cartSubject.next(this.cartItems);
  }

  getCartTotal(): number {
    return this.cartItems.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  }
}