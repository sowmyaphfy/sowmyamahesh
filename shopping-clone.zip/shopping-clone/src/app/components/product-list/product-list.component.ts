import { Component, OnInit } from '@angular/core';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';

@Component({
    selector: 'app-product-list',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
    products: Product[] = [];
    filteredProducts: Product[] = [];
    categories: string[] = ['Men', 'Women', 'Kids'];
    selectedCategory: string | null = null;
    sortOptions: string[] = ['Price: Low to High', 'Price: High to Low', 'Newest First'];
    selectedSort: string | null = null;

    constructor(private productService: ProductService) { }

    ngOnInit(): void {
        this.products = this.productService.getProducts();
        this.filteredProducts = [...this.products];
    }

    filterByCategory(category: string | null): void {
        this.selectedCategory = category;
        this.applyFilters();
    }

    sortProducts(sortOption: string | null): void {
        this.selectedSort = sortOption;
        this.applyFilters();
    }

    onSortChange(event: Event): void {
        const selectElement = event.target as HTMLSelectElement;
        this.sortProducts(selectElement.value || null);
    }

    applyFilters(): void {
        let filtered = [...this.products];

        // Category filter
        if (this.selectedCategory) {
            filtered = filtered.filter(product => product.category === this.selectedCategory);
        }

        // Sort
        if (this.selectedSort) {
            switch (this.selectedSort) {
                case 'Price: Low to High':
                    filtered.sort((a, b) => a.price - b.price);
                    break;
                case 'Price: High to Low':
                    filtered.sort((a, b) => b.price - a.price);
                    break;
                case 'Newest First':
                    // Assuming newer products have higher IDs
                    filtered.sort((a, b) => b.id - a.id);
                    break;
            }
        }

        this.filteredProducts = filtered;
    }
}