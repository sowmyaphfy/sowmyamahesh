import { Component, EventEmitter, Output } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { CartItem } from '../../models/product.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent {
  @Output() close = new EventEmitter<void>();
  cartItems$ = this.productService.getCart();
  cartTotal = 0;

  constructor(private productService: ProductService) {
    this.cartItems$.subscribe(items => {
      this.cartTotal = this.productService.getCartTotal();
    });
  }

  removeItem(item: CartItem): void {
    this.productService.removeFromCart(item);
  }

  updateQuantity(item: CartItem, quantity: number): void {
    if (quantity > 0) {
      this.productService.updateCartItem(item, quantity);
    } else {
      this.removeItem(item);
    }
  }

  closeCart(): void {
    this.close.emit();
  }
}