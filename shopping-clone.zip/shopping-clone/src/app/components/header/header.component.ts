import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { Observable } from 'rxjs';
import { CartItem } from '../../models/product.model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  cartItems$: Observable<CartItem[]>;
  cartTotal = 0;
  showCart = false;

  constructor(private productService: ProductService) {
    this.cartItems$ = this.productService.getCart();
  }

  ngOnInit(): void {
    this.cartItems$.subscribe(items => {
      this.cartTotal = items.reduce((total, item) => total + item.quantity, 0);
    });
  }

  toggleCart(): void {
    this.showCart = !this.showCart;
  }
}