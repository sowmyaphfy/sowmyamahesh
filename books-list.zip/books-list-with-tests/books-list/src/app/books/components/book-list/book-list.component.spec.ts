import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { BookListComponent } from './book-list.component';
import { BookService } from '../../services/book.service';
import { Book } from '../../models/book.model';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('BookListComponent', () => {
  let component: BookListComponent;
  let fixture: ComponentFixture<BookListComponent>;
  let bookService: jasmine.SpyObj<BookService>;

  const mockBooks: Book[] = [
    { id: '1', title: 'Test Book', authors: ['Author'], description: 'Test Desc', thumbnail: 'img.jpg' }
  ];

  beforeEach(async () => {
    const bookServiceSpy = jasmine.createSpyObj('BookService', ['getBooks']);

    await TestBed.configureTestingModule({
      declarations: [BookListComponent],
      imports: [HttpClientTestingModule],
      providers: [{ provide: BookService, useValue: bookServiceSpy }],
    }).compileComponents();

    bookService = TestBed.inject(BookService) as jasmine.SpyObj<BookService>;
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookListComponent);
    component = fixture.componentInstance;
  });

  it('should load books on init', () => {
    bookService.getBooks.and.returnValue(of(mockBooks));
    fixture.detectChanges();
    expect(component.books.length).toBe(1);
    expect(component.loading).toBeFalse();
  });

  it('should show error on API failure', () => {
    bookService.getBooks.and.returnValue(throwError(() => new Error('API error')));
    fixture.detectChanges();
    expect(component.error).toBe('API error');
    expect(component.loading).toBeFalse();
  });
});
