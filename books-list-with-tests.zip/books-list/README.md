# Books List App 📚

This Angular app lists books about "Fouling" using the Google Books API.

## Features
- Responsive design (mobile, desktop, large screen)
- API consumption with error/loading state
- Clean modular structure with services and components
- Unit tests for core features
- Accessible markup

## Angular Version
> This project is designed for Angular 14+. Make sure to use:
```bash
npm install -g @angular/cli@14
```

## Run Locally

1. Clone the repo
```bash
git clone https://github.com/yourname/books-list.git
cd books-list
```

2. Install dependencies
```bash
npm install
```

3. Run the project
```bash
ng serve
```

Navigate to `http://localhost:4200`
