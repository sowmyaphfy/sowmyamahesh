import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BookService } from './book.service';

describe('BookService', () => {
  let service: BookService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BookService],
    });
    service = TestBed.inject(BookService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should retrieve books from the API via GET', () => {
    const dummyBooks = {
      items: [
        {
          id: '1',
          volumeInfo: {
            title: 'Book Title 1',
            authors: ['Author 1'],
            description: 'Description 1',
            imageLinks: { thumbnail: 'thumb1.jpg' }
          }
        }
      ]
    };

    service.getBooks().subscribe(books => {
      expect(books.length).toBe(1);
      expect(books[0].title).toBe('Book Title 1');
    });

    const request = httpMock.expectOne('https://www.googleapis.com/books/v1/volumes?q=fouling');
    expect(request.request.method).toBe('GET');
    request.flush(dummyBooks);
  });
});
