# Dynamic Form Builder Application

This is an Angular application for building and managing dynamic forms with permission controls.

## Features

- Drag-and-drop form builder interface
- Multiple field types (text, textarea, select, checkbox, radio, date)
- Configurable field properties (label, required, validation rules)
- Form template management (create, edit, delete)
- Form preview and submission
- User roles (Admin and User) with permission controls
- Responsive design

## Requirements

- Angular 14+
- Node.js
- npm or yarn

## Installation

1. Clone the repository
2. Run `npm install`
3. Run `ng serve` for a dev server
4. Navigate to `http://localhost:4200/`

## Testing

Run `ng test` to execute the unit tests.

## Implementation Notes

- Used NgRx for state management
- Implemented drag-and-drop with Angular CDK
- Created mock services for API calls
- Added responsive design with Bootstrap
- Implemented unit tests for key components

## Challenges

- Implementing the drag-and-drop functionality required careful handling of form arrays
- Dynamic form validation based on configurable rules needed a flexible approach
- Role-based permissions were implemented using route guards