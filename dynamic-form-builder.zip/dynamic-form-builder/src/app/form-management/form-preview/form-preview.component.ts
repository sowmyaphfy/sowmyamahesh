import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-preview',
  templateUrl: './form-preview.component.html',
  styleUrls: ['./form-preview.component.scss']
})
export class FormPreviewComponent implements OnInit {
  fields: any[] = [];

  ngOnInit(): void {
    const preview = localStorage.getItem('previewTemplate');
    if (preview) {
      this.fields = JSON.parse(preview);
    }
  }
}
