import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormTemplate } from '../models/form-template.model';
import { FormService } from '../services/form.service';

@Component({
  selector: 'app-form-list',
  templateUrl: './form-list.component.html',
  styleUrls: ['./form-list.component.scss']
})
export class FormListComponent implements OnInit {
  forms: FormTemplate[] = [];
  userRole: string = '';

  constructor(private formService: FormService, private router: Router) {}

  ngOnInit(): void {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.userRole = user.role;

    this.forms = this.formService.getForms();
  }

  previewForm(form: FormTemplate): void {
    this.router.navigate(['/form-preview'], { state: { form } });
  }

  editForm(form: FormTemplate): void {
    this.router.navigate(['/form-builder'], { state: { form } });
  }

  deleteForm(formId: string): void {
    this.formService.deleteForm(formId);
    this.forms = this.formService.getForms();
  }

  createNewForm(): void {
    this.router.navigate(['/form-builder']);
  }
}
