import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { FormBuilderComponent } from './form-builder/form-builder.component';
import { FormListComponent } from './form-management/form-list.component';
import { FormPreviewComponent } from './form-management/form-preview/form-preview.component';
import { FormFillerComponent } from './form-submission/form-filler.component';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'form-builder', component: FormBuilderComponent},
  { path: 'form-list', component: FormListComponent },
  { path: 'form-preview', component: FormPreviewComponent},
  { path: 'form-filler', component: FormFillerComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
