
import { Component } from '@angular/core';

interface FormField {
  type: string;
  label: string;
  required: boolean;
  helpText?: string;
  options?: string[];
}

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.scss']
})
export class FormBuilderComponent {
  fields: FormField[] = [];

  addField(type: string) {
    const field: FormField = {
      type,
      label: `${type} Field`,
      required: false
    };

    if (type === 'dropdown' || type === 'radio' || type === 'checkbox') {
      field.options = ['Option 1', 'Option 2'];
    }

    this.fields.push(field);
  }

  removeField(index: number) {
    this.fields.splice(index, 1);
  }

  saveTemplate() {
    localStorage.setItem('formTemplate', JSON.stringify(this.fields));
    alert('Form template saved!');
  }
}
