import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-field-editor-dialog',
  templateUrl: './field-editor-dialog.component.html',
  styleUrls: ['./field-editor-dialog.component.scss']
})
export class FieldEditorDialogComponent {
  fieldForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<FieldEditorDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.fieldForm = this.fb.group({
      label: [data.label || '', Validators.required],
      required: [data.required || false],
      helpText: [data.helpText || ''],
      minLength: [data.minLength || null],
      maxLength: [data.maxLength || null],
      pattern: [data.pattern || ''],
      options: [data.options ? data.options.join(', ') : '']
    });
  }

  onSave(): void {
    const formValue = this.fieldForm.value;
    const updatedField = {
      ...this.data,
      label: formValue.label,
      required: formValue.required,
      helpText: formValue.helpText,
      minLength: formValue.minLength,
      maxLength: formValue.maxLength,
      pattern: formValue.pattern,
      options: formValue.options ? formValue.options.split(',').map((opt: string) => opt.trim()) : []
    };
    this.dialogRef.close(updatedField);
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}
