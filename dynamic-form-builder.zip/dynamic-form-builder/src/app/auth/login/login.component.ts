import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  username = '';
  role = '';
  roles = ['Admin', 'User'];

  constructor(private router: Router) {}

  login() {
    if (this.username && this.role) {
      localStorage.setItem('user', JSON.stringify({ username: this.username, role: this.role }));
      if (this.role === 'Admin') {
        this.router.navigate(['/form-list']);
      } else {
        this.router.navigate(['/form-filler']);
      }
    }
  }
}
