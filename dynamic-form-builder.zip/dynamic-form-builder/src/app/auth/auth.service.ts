
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

export type UserRole = 'Admin' | 'User';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private role: UserRole | null = null;
  private username: string | null = null;

  constructor(private router: Router) {}

  login(username: string, role: UserRole) {
    this.username = username;
    this.role = role;
  }

  logout() {
    this.username = null;
    this.role = null;
    this.router.navigate(['/login']);
  }

  getRole(): UserRole | null {
    return this.role;
  }

  isLoggedIn(): boolean {
    return !!this.role;
  }

  isAdmin(): boolean {
    return this.role === 'Admin';
  }
}
