import { FormField } from './form-field.model';

export interface FormTemplate {
  id: string;
  name: string;
  description?: string;
  fields: FormField[];
}
