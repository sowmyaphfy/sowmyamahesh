
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-form-filler',
  templateUrl: './form-filler.component.html',
  styleUrls: ['./form-filler.component.scss']
})
export class FormFillerComponent implements OnInit {
  form: FormGroup = this.fb.group({});
  fields: any[] = [];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    const saved = localStorage.getItem('formTemplate');
    
    if (saved) {
      this.fields = JSON.parse(saved);
      for (let field of this.fields) {
        const control = field.required ? [null, Validators.required] : [null];
        this.form.addControl(field.label,null);
      }
    }
  }

  onSubmit() {
    if (this.form.valid) {
      console.log('Form submitted:', this.form.value);
      alert('Form submitted successfully!');
    } else {
      alert('Form is invalid.');
    }
  }
}
