import { Injectable } from '@angular/core';
import { FormTemplate } from '../models/form-template.model';
import { v4 as uuidv4 } from 'uuid';

@Injectable({
  providedIn: 'root'
})
export class FormService {
  private storageKey = 'form_templates';

  constructor() {}

  getForms(): FormTemplate[] {
    const raw = localStorage.getItem(this.storageKey);
    return raw ? JSON.parse(raw) : [];
  }

  getFormById(id: string): FormTemplate | undefined {
    return this.getForms().find(form => form.id === id);
  }

  saveForm(form: FormTemplate): void {
    const forms = this.getForms();
    if (!form.id) {
      form.id = uuidv4();
      forms.push(form);
    } else {
      const index = forms.findIndex(f => f.id === form.id);
      if (index !== -1) {
        forms[index] = form;
      } else {
        forms.push(form);
      }
    }
    localStorage.setItem(this.storageKey, JSON.stringify(forms));
  }

  deleteForm(id: string): void {
    const forms = this.getForms().filter(f => f.id !== id);
    localStorage.setItem(this.storageKey, JSON.stringify(forms));
  }
}
