import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SubmissionService {
  private submissionsKey = 'formSubmissions';

  submitForm(data: any) {
    const submissions = this.getSubmissions();
    submissions.push(data);
    localStorage.setItem(this.submissionsKey, JSON.stringify(submissions));
  }

  getSubmissions(): any[] {
    const data = localStorage.getItem(this.submissionsKey);
    return data ? JSON.parse(data) : [];
  }
}
