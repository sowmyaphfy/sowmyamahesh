import React from "react";

function MovieList({movies})
{
    if(movies.length===0) return <p>No Movies found.</p>;

    return(
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,200)',gap:'10px',marginTop:'20px'}}>
        {
            movies.map((movie)=>(
                <div key={movie.imdId} style={{border:'1px solid #ccc',padding:'10px'}}>
                    <img src={movie.poster} alt={movie.Title} style={{width:'100%'}} />
                    <h4>{movie.Title}</h4>
                    <p>{movie.Year}</p>
                </div>
            ))
        }
          </div>
    )
}
export default MovieList;