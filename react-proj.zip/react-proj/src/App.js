import React, { useState } from "react";
import SearchBar from "./components/SearchBar";
import MovieList from "./components/MovieList";
import axios from 'axios';

const API_KEY='your_api_key_here';

function App(){
const [movies,setMovies]=useState([]);

const searchMovies=async (query)=>{
  if(!query) return;
  {
    const response=await axios.get(`https://www.omdbapi.com/?apikey=${API_KEY}&s=${query}`);
    searchMovies(response.data.Search || [])

  }

  return (
    <div style={{padding:'20px'}}>
      <h1>Movie Search</h1>
      <SearchBar onSearch={searchMovies}/>
      <MovieList movies={movies} />
    </div>
  )
}
}

export default App;